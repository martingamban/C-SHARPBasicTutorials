﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_Laboratory_Exercise_1
{
    class ClubRegistrationQuery
    {
        private SqlConnection sqlConnect;
        private SqlCommand sqlCommand;
        private SqlDataAdapter sqlAdapter;

        public DataTable dataTable;
        public BindingSource bindingSource;
        private string connectionString;

        public int _Id;
        public string _FirtName, _MiddleName, _LastName, _Gender, _Program;
        public int _StudentId, _Age;

        public ClubRegistrationQuery()
        {
            connectionString = @"Data Source=LAPTOP-VE7RJ07I\SQLEXPRESS;Initial Catalog=ClubDB;Integrated Security=True";
            sqlConnect = new SqlConnection(connectionString);
            dataTable = new DataTable();
            bindingSource = new BindingSource();
        }
        public bool DisplayList()
        {
            try
            {
                string ViewClubmembers = "SELECT StudentId, FirstName, MiddleName, LastName, Age, Gender, Program FROM ClubMembers";
                sqlAdapter = new SqlDataAdapter(ViewClubmembers, sqlConnect);
                dataTable.Clear();
                sqlAdapter.Fill(dataTable);
                bindingSource.DataSource = dataTable;
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Message: " + ex.Message);
                return false;
            }
        }

        public bool RegisterStudent(long StudentID, string FirstName, string MiddleName, string LastName, int Age, string Gender, string Program)
        {
            try
            {
                sqlCommand = new SqlCommand("INSERT INTO ClubMembers VALUES (@StudentID, @Fname, @Mname, @LName, @Age, @Gender, @Program)", sqlConnect);
                sqlCommand.Parameters.Add("@StudentID", SqlDbType.BigInt).Value = StudentID;
                sqlCommand.Parameters.Add("@Fname", SqlDbType.VarChar).Value = FirstName;
                sqlCommand.Parameters.Add("@Mname", SqlDbType.VarChar).Value = MiddleName;
                sqlCommand.Parameters.Add("@Lname", SqlDbType.VarChar).Value = LastName;
                sqlCommand.Parameters.Add("@Age", SqlDbType.Int).Value = Age;
                sqlCommand.Parameters.Add("@Gender", SqlDbType.VarChar).Value = Gender;
                sqlCommand.Parameters.Add("@Program", SqlDbType.VarChar).Value = Program;

                sqlConnect.Open();
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Successfully Added!");
                sqlConnect.Close();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Message: " + ex.Message);
                return false;
            }
        }
        public bool UpdateStudent(int Id, string FirstName, string MiddleName, string LastName, int Age, string Gender, string Program)
        {
            try
            {
                sqlConnect.Open();
                sqlCommand = new SqlCommand("UPDATE ClubMembers SET FirstName=@Fname, MiddleName = @Mname ,LastName=@Lname, Age=@Age, Gender=@Gender, Program = @Program WHERE id =@ID", sqlConnect);

                sqlCommand.Parameters.AddWithValue("@ID", Id);
                sqlCommand.Parameters.AddWithValue("@Fname", FirstName);
                sqlCommand.Parameters.AddWithValue("@Mname", MiddleName);
                sqlCommand.Parameters.AddWithValue("@Lname", LastName);
                sqlCommand.Parameters.AddWithValue("@Age", Age);
                sqlCommand.Parameters.AddWithValue("@Gender", Gender);
                sqlCommand.Parameters.AddWithValue("@Program", Program);

                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Successfully Updated!");
                sqlConnect.Close();
                return true;

            }
            catch (Exception ex)
            {

                Console.WriteLine("Error Update Message: " + ex.Message);
                return false;
            }

        }

        public int ID
        {
            get
            {
                return this._Id;
            }
            set 
            {
                this._Id = (int)ID;
            }
        }

        public long StudentID
        {
            get 
            {
                return this._StudentId;
            }
            set
            {
                this._StudentId = (int)StudentID;
            }
        }

        public string Firstname
        {
            get 
            {
                return this._FirtName;
            }
            set
            {
                this._FirtName = Firstname;
            }
        }

        public string MiddleName
        {
            get
            {
                return this._MiddleName;
            }
            set
            {
                this._MiddleName = MiddleName;
            }
        }

        public string LastName
        {
            get
            {
                return this._LastName;
            }
            set
            {
                this._LastName = LastName;
            }
        }

        public int Age
        {
            get
            {
                return this._Age;
            }
            set
            {
                this.Age = Age;
            }
        }

        public string Gender
        {
            get
            {
                return this._Gender;
            }
            set
            {
                this._Gender = Gender;
            }
        }

        public string Program
        {
            get
            {
                return this._Program;
            }
            set
            {
                this._Program = Program;
            }
        }
    }
}

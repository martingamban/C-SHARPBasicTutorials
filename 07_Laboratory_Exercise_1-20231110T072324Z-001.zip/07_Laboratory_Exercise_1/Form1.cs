﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _07_Laboratory_Exercise_1
{
    public partial class Form1 : Form
    {
        private ClubRegistrationQuery clubRegistrationQuery;
        private int Age;
        private long Studentid;
        private string FirstName, MiddleName, LastName, Gender, Program;

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (txtStudentid.Text == "" || txtFname.Text == "" || txtMname.Text == ""
                || txtLname.Text == "" || txtAge.Text == "" || cbGender.SelectedIndex == -1 || cbProgram.SelectedIndex == -1)
            {
                MessageBox.Show("Please Fill up the required field/s", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else 
            {
                InputData();
                clubRegistrationQuery.RegisterStudent(Studentid, FirstName, MiddleName, LastName, Age, Gender, Program);
                RefreshListofMembers();
                ClearInput();
            }
 
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshListofMembers();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            clubRegistrationQuery = new ClubRegistrationQuery();
            RefreshListofMembers();
            clubRegistrationQuery.DisplayList();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            frmUpdateMember fum = new frmUpdateMember();
            fum.Show();
        }

        private void dgvMembers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtStudentid_TextChanged(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }
        public void RefreshListofMembers()
        {
            clubRegistrationQuery.DisplayList();
            dgvMembers.DataSource = clubRegistrationQuery.bindingSource;
        }

        public void InputData()
        {
            Studentid = Convert.ToInt32(txtStudentid.Text);
            FirstName = txtFname.Text;
            MiddleName = txtMname.Text;
            LastName = txtLname.Text;
            Age = Convert.ToInt32(txtAge.Text);
            Gender = cbGender.Text;
            Program = cbProgram.Text;
        }

        public void ClearInput()
        {
            txtStudentid.Clear();
            txtFname.Clear();
            txtMname.Clear();
            txtLname.Clear();
            txtAge.Clear();
            cbGender.SelectedIndex = -1;
            cbProgram.SelectedIndex = -1;
        }
    }
}
